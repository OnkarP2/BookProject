package com.ct.account;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table

public class User {
	@Id
	@Size(min=3, max=16,message="Username cannot be less than 3")
	private String username;
	@Size(min=3, max=16,message="First name cannot be less than 3")
	@Column(name="fname")
	private String fname;
	@Size(min=3, max=16,message="Last name cannot be less than 3")
	@Column(name="lname")
	private String lname;
	@NotEmpty(message="field is mandatory")
	@Size(min=3, max=16,message="username cannot be less than 3")
	private String password;
	@Email
	@NotEmpty(message="email is mandatory")
	private String email;
	@NotEmpty(message="mobile number is mandatory")
	@Pattern(regexp="([0-9]{10})")
	private String phone;
	@NotEmpty(message="field is mandatory")
	private String plan;

	
	public User(String username, String fname, String lname, String password, String email, String phone,
			String plan) {
		super();
		this.username = username;
		this.fname = fname;
		this.lname = lname;
		this.password = password;
		this.email = email;
		this.phone = phone;
		this.plan = plan;

	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPlan() {
		return plan;
	}
	public void setPlan(String plan) {
		this.plan = plan;
	}
	public User() {
		
	}
	
	
	
}
