package com.ct.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ct.model.Product;
import com.ct.service.ProdService;
import com.ct.account.Login;
import com.ct.account.User;
import com.ct.dao.ProdDao;


@Controller
public class ProductController {
	static HashMap<Integer, Product> h1= new HashMap<Integer, Product>();
	List<Product>prodList=null;
	Product product=null;
	Boolean isAllowed=false;
	@Autowired
	private ProdService prodService;

	
	@RequestMapping("/")
	public String getHomePage(){
		
		return "homepage";

	}
	
	@RequestMapping("index")
	public String returnHomePage(HttpServletRequest request){
		
		prodList=prodService.viewAllProducts();
		request.setAttribute("list", prodList);
		return "index";
	}
	
	@RequestMapping(value="/store",method=RequestMethod.POST)
	public String storeProductInDb(@Valid @ModelAttribute("prod") Product product,BindingResult br,Model m,@RequestParam CommonsMultipartFile file,HttpSession session) throws Exception{
		if(br.hasErrors()) {
			System.out.println(br);
			return "add";
		}
		else {
			String str= saveImage(file,session);
			product.setProdImage(str);
	        String status=prodService.saveProduct(product);
	        System.out.println(product);
	        m.addAttribute("msg", status);
		}
		return "add";
	}
	
	
	@RequestMapping("/store")
	public String getStorepage(Model m) {
		Product p=new Product();
		m.addAttribute("prod",p);
		return "add";
	}

	
	@RequestMapping("/retrieveall")
	public String getAll(HttpServletRequest request) {
//		 h1=prodService.saveProduct();
		prodList=prodService.viewAllProducts();
		request.setAttribute("list", prodList);
		return "retrieveall";
	}
	
	
	
	
	/*@RequestMapping(value="/store",method=RequestMethod.POST)
	public @ResponseBody Product storeProductInDb(@RequestBody @Valid @ModelAttribute("prod") Product product,BindingResult br,Model m){
		if(br.hasErrors()) {
			System.out.println(br);
			System.out.println(product);
			return product;
		}
		else {
			
	        String status=prodService.saveProduct(product);
	    	System.out.println(product);
	        m.addAttribute("msg", status);
		}
		return product;
	}
	*/
	@RequestMapping("/upload")
	public String getUploadPage() {
	
		return "upload";
	}
//	@RequestMapping(value="/upload",method=RequestMethod.POST)
	public String saveImage(CommonsMultipartFile file,  
	           HttpSession session) throws Exception{  
		String path=session.getServletContext().getRealPath("/");  
	   System.out.println(path);
	    String filename = file.getOriginalFilename();  

	    byte[] bytes = file.getBytes();  
	    BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(new File(path+ File.separator+"Resources/images/" + filename)));  
	    stream.write(bytes);  
	    stream.flush();  
	    stream.close();
	    return filename;
	   // return new ModelAndView("upload","filesuccess","File successfully saved!");  
	    }  
	
	
	/*@RequestMapping(value="/upload",method=RequestMethod.POST)
	public ModelAndView saveimage( @RequestParam CommonsMultipartFile file,  
	           HttpSession session) throws Exception{  
		String path=session.getServletContext().getRealPath("/");  
	   
	    String filename = file.getOriginalFilename();  

	    byte[] bytes = file.getBytes();  
	    BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(new File(path+ File.separator+"Resources/images/" + filename)));  
	    stream.write(bytes);  
	    stream.flush();  
	    stream.close();  
 
	    return new ModelAndView("upload","filesuccess","File successfully saved!");  
	    } */
	
	
	
	
	
	@RequestMapping("/searchbyid")
	public String getSearchpage() {
		
		return "getbyid";
	}
	
	@RequestMapping(value="/search",method=RequestMethod.POST)
	public String search(@RequestParam ("number") int id,HttpServletRequest request) {
		
		product=prodService.viewProduct(id);
		request.setAttribute("prod",product);
		return "getbyid";
	}
	@RequestMapping("/search")
	public String searchProd(@RequestParam ("id") int id,HttpServletRequest request) {
		
		product=prodService.viewProduct(id);
		request.setAttribute("prod",product);
		return "getbyid";
	}
	
	@RequestMapping("/remove")
	public String getRemovepage() {
		
		return "remove";
	}
	
	@RequestMapping(value="/remove",method=RequestMethod.POST)
	public String removeProd(@RequestParam ("number") int id,HttpServletRequest request) {
		
		String msg1=prodService.deleteProduct(id);
		request.setAttribute("msg1",msg1);
		return "remove";
	}
	
	@RequestMapping("login")
	public ModelAndView getLoginPage(){
		ModelAndView mv = new ModelAndView();
		Login login=new Login();
		mv.addObject(login);
		mv.setViewName("login");
		return mv;
	}
	
	@RequestMapping(value="login",method=RequestMethod.POST)
	public String getLogin(@Valid@ModelAttribute("login") Login login,BindingResult br,HttpServletRequest request){
	//	ModelAndView mv=new ModelAndView();
		if(br.hasErrors())
		{
			return "login";
		}
		else
		{
	
		isAllowed=prodService.login(login);
		if(isAllowed)
		{
		HttpSession session=request.getSession(true);
		session.setAttribute("role", login.getRole());
		session.setAttribute("username", login.getUsername());
		session.setAttribute("isAllowed", isAllowed);
		return "index";
		}
		else
		{
		request.setAttribute("msg", "Please enter the correct credentials");
		return "login";
		}
		}
	}
	
	@RequestMapping("logout")
	public String logoutPage(HttpServletRequest request){
		
		HttpSession session=request.getSession(false);
		session.invalidate();
		return "homepage";
	}
	
	@RequestMapping("register")
	public ModelAndView getRegisterPage(){
		ModelAndView mv = new ModelAndView();
		
		User user=new User();
		mv.addObject(user);
		mv.setViewName("register");
		return mv;
	}
	
	@RequestMapping(value="register",method=RequestMethod.POST)
	public String getRegister(@Valid@ModelAttribute("user") User user,BindingResult br,HttpServletRequest request){
	//	ModelAndView mv=new ModelAndView();
		if(br.hasErrors())
		{
			return "register";
		}
		else
		{
		isAllowed=prodService.searchUsername(user);
		if(!isAllowed)
		{
		request.setAttribute("msg1", "Username already exists");
		}
		else
		{
		isAllowed=prodService.register(user);
		request.setAttribute("msg1", "User successfully registered");
		}
		return "register";
		}
	}
	
	@ModelAttribute
	public void retrieveall(Model model)
	{
		prodList=prodService.viewAllProducts();
		model.addAttribute("list", prodList);
	}
	
	
}
