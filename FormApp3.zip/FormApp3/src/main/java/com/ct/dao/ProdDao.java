package com.ct.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.transform.DistinctRootEntityResultTransformer;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.ModelAndView;

import com.ct.account.Login;
import com.ct.account.User;
import com.ct.model.Product;
import com.ct.util.HibernateUtil;


@Repository
public class ProdDao {
		
	Product pr=null;
	List<Product> al=new ArrayList<Product>();
	@Autowired
	private JdbcTemplate jdbcTemplate;  
	@Autowired
	HibernateUtil hibernateUtil;
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	  
	public String saveProduct(Product product)
	{
		
		pr=product;
		Session session = hibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
  
	
        session.save(pr);
        
       // Product product = (Product)session.load(com.ct.hibernate.module.Product.class, 2);
 
		session.getTransaction().commit(); 
		session.close();
	//	getJdbcTemplate().update("insert into product (prodName,price,prodQty,description,discount) values(?,?,?,?,?)",new Object[] {product.getProdName(),product.getPrice(),product.getProdQty(),product.getDescription(),product.getDiscount()});
		 return "data of "+product.getProdName()+" is added";
	}

	
	
	
	public Product viewProduct(int id)
	{
		Product product=null;
		Session session = hibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		
	
       // Product product = (Product)session.load(com.ct.hibernate.module.Product.class, 2);
   	 	product = (Product)session.get(com.ct.model.Product.class, id);
   	 
		session.getTransaction().commit(); 
	
		session.close();
	//	getJdbcTemplate().update("insert into product (prodName,price,prodQty,description,discount) values(?,?,?,?,?)",new Object[] {product.getProdName(),product.getPrice(),product.getProdQty(),product.getDescription(),product.getDiscount()});
		 return product;
	}
	
	public String deleteProduct(int id)
	{
		Product product=null;
		Session session = hibernateUtil.getSessionFactory().openSession();
	
        session.beginTransaction();

   	 	product = (Product)session.get(com.ct.model.Product.class, id);
   	 	session.delete(product);
   	 	
   	 	
   	 
		session.getTransaction().commit(); 
	
		session.close();
		 return "data of "+product.getProdName()+" is deleted";
	}
	
	public List<Product> viewAllProducts()
	{
		Product product=null;
		
		Session session = hibernateUtil.getSessionFactory().openSession();
		
        session.beginTransaction();

        Criteria crit=session.createCriteria(Product.class);
        List<Product> prodList=crit.list();
   	
		session.getTransaction().commit(); 
	
		session.close();
		 return prodList;
	}
	
	
	
	public Boolean login(Login login)
	{
	
		Session session = hibernateUtil.getSessionFactory().openSession();
		
        session.beginTransaction();
        Criteria crit=session.createCriteria(Login.class);
       // Disjunction objDisjunction = Restrictions.disjunction();
        /* Add multiple condition separated by OR clause within brackets. */
       // objDisjunction.add(Restrictions.eq("username", login.getUsername())).add(Restrictions.eq("password", login.getPassword()));
      
        
        /* Attach Disjunction in Criteria */
        crit.add(Restrictions.eq("username", login.getUsername()));
        crit.add(Restrictions.eq("password", login.getPassword()));
        crit.add(Restrictions.eq("role", login.getRole()));
        
        List lglist=crit.list();
        
      
		
		session.close();
	//	getJdbcTemplate().update("insert into product (prodName,price,prodQty,description,discount) values(?,?,?,?,?)",new Object[] {product.getProdName(),product.getPrice(),product.getProdQty(),product.getDescription(),product.getDiscount()});
		if(lglist.isEmpty())
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	public Boolean register(User user)
	{
	
		Session session = hibernateUtil.getSessionFactory().openSession();
		
        session.beginTransaction();
        session.save(user);
        session.save(new Login("user",user.getUsername(),user.getPassword()));

        /* Add multiple condition separated by OR clause within brackets. */
        
        
      
        session.getTransaction().commit();
		session.close();
	//	getJdbcTemplate().update("insert into product (prodName,price,prodQty,description,discount) values(?,?,?,?,?)",new Object[] {product.getProdName(),product.getPrice(),product.getProdQty(),product.getDescription(),product.getDiscount()});
		
			return true;
		
	}
	
	
	public boolean searchUsername(User user)
	{
		
		Session session = hibernateUtil.getSessionFactory().openSession();
		
        session.beginTransaction();
	
        Criteria crit=session.createCriteria(User.class);
        crit.add(Restrictions.eq("username", user.getUsername()));
        List userlist=crit.list();
   	 	
   	 
		session.getTransaction().commit(); 
	
		session.close();
		if(userlist.isEmpty())
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	
	
	
}


